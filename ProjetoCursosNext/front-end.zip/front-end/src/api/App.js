import axios from 'axios'
import {useEffect, useState} from 'react'

function App(props) {

  const baseUrl = 'https://localhost:44397/api/cursoes'
  const [data, setData]=useState([]);

  const pedidoGet=async()=>{
    await axios.get(baseUrl)
    .then(res=>{
      setData(res.data);
    }).catch(erro=>{
      console.log(erro);
    })
     /* await fetch(baseUrl)
      .then((res) => res.json())
      .then(
          (resultado) =>{
              setData(resultado)
          })  */      
      
      /*fetch(baseUrl)
      .then(res => res.json)
      .then((resultado) =>{
              setData(resultado)
          }
      )*/

    props.data
  }

  useEffect(()=>{
      pedidoGet();
  })
      
  /*fetch(baseUrl)
  .then((res) => res.json())
  .then(
    (resultado) =>{
      setData(resultado)
    }
    )*/
    
        
}
export default App