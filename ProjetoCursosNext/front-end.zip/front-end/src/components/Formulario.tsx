import Entrada from "./Entrada"
import { useState, useEffect } from "react"
import Botao from "./Botao"
import {Curso, cursoApi} from "../api/curso.api"
import { cursoEditado, opcaoBotao } from "../pages"
import setVisivel from "../pages/index"


export default function Formulario(props /*: FormularioProps*/){

    
    /*const pedidoPost=async()=>{
        delete cursoSelecionado.id;                
        await axios.post(baseUrl, cursoSelecionado)
        .then(res =>{
            setData(data.concat(res.data));
            valorMudou('tabela')
        }).catch(error =>{
            console.log(error);                
        })
    }*/

    const [curso, setCurso] = useState([]);
    const [cursoObj, setCursoObj] = useState({} as Curso);
    const [editarForm, setEditarForm]  = useState(false);
    
    
    function salvar(){
        cursoApi.post(cursoObj)
        .then(res => res && 201 ? mensagemSalvar() : alert('Curso Não foi salvo'))
        .then(res => console.log("infome o response da api=====>",res))        
        
      }
    
      function mensagemSalvar(){
        alert('Curso salvado com sucesso!!!')
        location.reload()
      }
    
    
    function Editar(){
        setCursoObj(cursoEditado)
        cursoApi.put(cursoEditado.cursoID, cursoObj)
        .then(res=> res && 201 ? alert("Editado com sucesso"+ res.status ): alert('nao foi salvo erro' + res))        
    }

   
        
    const id = props.curso?.id ?? null 


    const handleChange =e=>{
        const{name, value}=e.target;
        setCursoObj({
            ...cursoObj,
            [name]: value
        });
        console.log(cursoObj);        
    }  

    

    return (
        <div className={`
        flex flex-col`}>
            {/**Form cadastro */}
            {opcaoBotao === 'Salvar'? (
                <>
                <label>"Nome Curso"</label>
                <input
                type="string"
                name="nomeCurso"
                onChange={handleChange}
                className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}
                
                />
                <label>"Quantidade de Alunos"</label>
                <input
                type="number"
                name="qtdAlunos"
                onChange={handleChange} 
                className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}
                
                />
                <label>"Data Inicio"</label> 
                <input
                type="date" 
                name="dtInicio"
                onChange={handleChange}
                className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}
                
                />
                <label>"Data Termino"</label>
                <input 
                type="date" 
                name="dtTermino"
                onChange={handleChange}
                className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}
                
                />
                <label>"Descrição"</label>
                <input 
                type="texto" 
                name="descricao"
                onChange={handleChange}
                className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}
                
                />
                <label>"Categoria"</label>
                <input 
                type="texto" 
                name="categoria"
                onChange={handleChange}
                className={`
                    border border-b-gray-500 rounded-lg
                    focus:outline-none bg-stone-400
                    px-4 py-2 "mb-4"
                    `}
                    
                    />
                    <div className="flex justify-end mt-3">
                <Botao className="mr-3"
                    //onClick={()=>props.cursoMudou?.(new cursoAtt(id, cursoAtt.nomeCurso, cursoAtt.qtdAlunos, cursoAtt.dtInicio, cursoAtt.dtTermino, cursoAtt.descricao))}
                    onClick={()=>salvar()} 
                    >                    
                    Salvar
                    {console.log('eu quero saber resultado de cursoObj.cursoID: ',cursoEditado )}
                </Botao>
                <Botao onClick={props.cancelado}>
                    Cancelar
                </Botao>
            </div>
            </>
        ):(
            <>            
            {/*Form do Editar */}
            
            <label>"ID"</label>
            <label>
                <h1 className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}>
                    {cursoEditado.cursoID}
                </h1>
            </label>

             <label>"Nome Curso"</label>
                <input
                type="string"
                name="nomeCurso"
                onChange={handleChange}
                value = {cursoEditado.nomeCurso || cursoObj.nomeCurso }
                className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}
                
                />
                <label>"Quantidade de Alunos"</label>
                <input
                type="number"
                name="qtdAlunos"
                onChange={handleChange}
                value = {cursoEditado.qtdAlunos} 
                className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}
                
                />
                <label>"Data Inicio"</label> 
                <input
                type="date" 
                name="dtInicio"
                onChange={handleChange}
                value = {cursoEditado.dtInicio}
                className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}
                
                />
                <label>"Data Termino"</label>
                <input 
                type="date" 
                name="dtTermino"
                onChange={handleChange}
                value = {cursoEditado.dtTermino}
                className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}
                
                />
                <label>"Descrição"</label>
                <input 
                type="texto" 
                name="descricao"
                value = {cursoEditado.descricao}
                onChange={handleChange}
                className={`
                border border-b-gray-500 rounded-lg
                focus:outline-none bg-stone-400
                px-4 py-2 "mb-4"
                `}
                
                />
                <label>"Categoria"</label>
                <input 
                type="texto" 
                name="categoria"
                onChange={handleChange}
                value = {cursoEditado.categoria}
                className={`
                    border border-b-gray-500 rounded-lg
                    focus:outline-none bg-stone-400
                    px-4 py-2 "mb-4"
                    `}
                    
                    />
                    <div className="flex justify-end mt-3">
                <Botao className="mr-3"
                    //onClick={()=>props.cursoMudou?.(new cursoAtt(id, cursoAtt.nomeCurso, cursoAtt.qtdAlunos, cursoAtt.dtInicio, cursoAtt.dtTermino, cursoAtt.descricao))}
                    onClick={()=>Editar()} 
                    >                    
                    Editar
                    {console.log('eu quero saber resultado de cursoEditado: ', cursoEditado )}
                    {console.log('eu quero saber resultado de cursoObj: ', cursoObj )}
                </Botao>
                <Botao onClick={props.cancelado}>
                    Cancelar
                </Botao>
            </div>
            
            </>
        )}
        </div>
    )
}

function valorMudou(tabela: any) {
    throw new Error("Function not implemented.")
}
