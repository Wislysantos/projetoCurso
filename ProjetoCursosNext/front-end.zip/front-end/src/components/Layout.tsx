import Titulo from "./Titulo";
import Botao from "./Botao";

interface LayoutProps{
    titulo: string;
    children: any;
}

export default function Layout(props: LayoutProps){
    return (
        <div className={`
        flex flex-col w-3/4 
        bg-zinc-400 text-white rounded-md
           
        `}>
            <Titulo>{props.titulo}</Titulo>                
            <div className="p-6">               
                {props.children}
            </div>

        </div>


    )
}