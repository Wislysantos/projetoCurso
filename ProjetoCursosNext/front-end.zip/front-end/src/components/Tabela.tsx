import {Curso, cursoApi} from "../api/curso.api"
import {IconeEdicao, IconeLixeira} from "./Incones"
import { useState} from "react"
import { cursoEditado } from "../pages";


/*
export default function TabelaCursos(){  

    cursos: Curso[]
    CursoSelecionado?: (curso: Curso) => void
    CursoExcluido?: (curso: Curso) => void
}
*/


export default function Tabela(props){

    const [curso, setCurso] = useState([])
    const [cursoObj, setCursoObj] = useState({} as Curso);

    function mostrarDados() {
        cursoApi.lista()
        .then((res) => {
            setCurso(res.data)
        })
    }
    //mostrarDados();   
    /*const pedidoGet = async()=>{
        await axios.get(baseUrl)
        .then(res => setData(res.data))
    }
    
    useEffect(()=>{
        mostrarDados()
    })
    */ 

            
    const exibirOperacao =  props.cursoSelecionado || props.cursoExcluido
    
    function renderizarCabecalho(){
        
        return(
            
            <tr>
                <th className="text-center p-4" >Nome Curso</th>
                <th className="text-center p-4" >Qtd Alunos</th>
                <th className="text-center p-4" >Data Inicio</th>
                <th className="text-center p-4" >Data Termino</th>
                <th className="text-center p-4" >Descrição</th>
                <th className="text-center p-4" >Categoria</th>
                {exibirOperacao? <th className="text-center p-4" >Operação</th>: false }
            </tr>
        )
    }

    function renderizarDados(){
        return curso?.map((curso, i)=> {
            return(
                <tr key={curso.cursoid}
                    className={` ${i % 2 === 0 ? 'bg-gray-500' : 'bg-slate-700'}
                    text-slate-200 `}>
                    <td className="text-center p-4" >{curso.nomeCurso}</td>
                    <td className="text-center p-4" >{curso.qtdAlunos}</td>
                    <td className="text-center p-4" >{curso.dtInicio}</td>
                    <td className="text-center p-4" >{curso.dtTermino}</td>
                    <td className="text-center p-4" >{curso.descricao}</td>
                    <td className="text-center p-4" >{curso.categoria}</td>                    
                    {exibirOperacao ? renderizarOperacao(curso) : false}
                </tr>
            )
        })
    }

    function renderizarOperacao(curso: Curso){
        return(
            <td className="flex">
                {props.cursoSelecionado ? (
                    <button onClick={() => props.cursoSelecionado(curso, 'Editar') }
                    
                    className={`
                        flex justify-center items-center
                        rounded-full p-2 m-1 
                        text-slate-900 hover:bg-neutral-50
                    `}>
                        {IconeEdicao}
                        </button>
                ): false}

                {props.cursoSelecionado ? (
                    <button onClick={()=>props.cursoExcluido(curso.cursoID)}
                    className={`
                        flex justify-center items-center
                        rounded-full p-2 m-1 
                        text-slate-900 hover:bg-neutral-50
                    `}  >
                        {IconeLixeira}
                        </button>

                ): false}
            </td>

        )
    }


    
    
    return(
        <div onMouseMove={mostrarDados}>   
            

            <table className="w-full rounded-xl overflow-hidden">
                <thead className={`
                    bg-gradient-to-r from-slate-900 to-slate-500
                    text-white
                    `}>
                    {renderizarCabecalho()}
                </thead>
                <tbody>
                    {renderizarDados()}
                </tbody>
            </table>
        </div>
        
    )
    
}

