interface EntradaProps{
    tipo?: 'texto' |'number' |'date'
    texto: string
    valor?: any
    somenteLeitura?:boolean
    className?: string
    onChange?: (event: any) => void
    

}

export default function Entrada(props : EntradaProps){
    return(
        <div className={`
             flex flex-col ${props.className}
        `}>
            <label className="mb-2">
                {props.texto}
            </label>
            <input 
                type={props.tipo ?? 'text'}
                name={props.valor}
                readOnly={props.somenteLeitura}           
                className={`
                    border border-b-gray-500 rounded-lg
                    focus:outline-none bg-stone-400
                    px-4 py-2
                `}           
            />
        </div>
    )
}