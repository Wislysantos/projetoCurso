export default class Curso{
     #id: number;
     #nomeCurso: string;
     #qtdAlunos: number;
     #dtInicio: string;
     #dtTermino: string;
     #descricao: string;

    constructor(id: number = null, nomeCurso: string, qtdAlunos: number, dtInicio: string, dtTermino: string, descricao: string){
        this.#id = id
        this.#nomeCurso =nomeCurso
        this.#qtdAlunos = qtdAlunos
        this.#dtInicio = dtInicio
        this.#dtTermino = dtTermino
        this.#descricao = descricao
    }

    static vazio(){
        return new Curso(0, '', 0, '', '', '')
    }

    get id(){
        return this.#id
    }

    get nomeCurso(){
        return this.#nomeCurso
    }

    get qtdAlunos(){
        return this.#qtdAlunos
    }

    get dtInicio(){
        return this.#dtInicio
    }

    get dtTermino(){
        return this.#dtTermino
    }

    get descricao(){
        return this.#descricao
    }


}