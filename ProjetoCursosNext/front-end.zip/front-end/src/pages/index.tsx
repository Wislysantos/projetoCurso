import Layout from "../components/Layout"
import Tabela from "../components/Tabela"
import Botao from "../components/Botao"
import Formulario from "../components/Formulario"
import {useState} from "react"
import {Curso, cursoApi} from "../api/curso.api"

export let opcaoBotao, cursoEditado

export default function Home() {
  
  const [visivel, setVisivel] = useState <'tabela'|'formulario'>('tabela') 
  const [cursoObj, setCursoObj] = useState({} as Curso);
  const [curso, setCurso] = useState([])

 
  
  /*function cursoSelecionado(curso: Curso){
      setCursoObj(curso)
      setVisivel('formulario')
      
  }*/

  const cursoSelecionado=(cursoObj, opcao)=>{
    setCursoObj(cursoObj.nomeCurso);
    /*console.log(cursoObj); 
    console.log(cursoObj);
    console.log(opcao);*/
    cursoEditado = cursoObj
    opcaoBotao = opcao
    opcao == "Editar" ? setVisivel('formulario') : setVisivel('tabela')
    
  }

  
  
  function cursoExcluido(id){
    console.log(`Excluido... ${id}`);
    cursoApi.delete(id)
    .then((res) => console.log(res))   
  }

  function novoCurso(){
    opcaoBotao = 'Salvar'
    console.log(opcaoBotao);
    
    //setCursoObj(cursoObj.vazio())
    setVisivel('formulario')
  }

  function cursoSalvar(curso: Curso){
    console.log(curso);
    setVisivel('tabela')
  }

  return (
    <div className={`
    flex h-screen justify-center items-center
    bg-gradient-to-r from-neutral-700 to-slate-900
    text-white
    `}>
      <Layout titulo="Curso" >
        {visivel === 'tabela'?(
          <>          
          <div className="flex justify-end">
            <Botao className="mb-4"                
              onClick={() =>novoCurso() }>
              Cadastrar Curso
            </Botao>
          </div>
          <Tabela curso={cursoObj} 
            cursoSelecionado={cursoSelecionado}
            cursoExcluido={cursoExcluido}
        />
      </>     

        ): (
          <Formulario 
            curso={cursoObj}
            cancelado={()=>setVisivel('tabela')}
            cursoMudou={cursoSalvar}
          />
        )}
      </Layout>
    </div>
  )
}
